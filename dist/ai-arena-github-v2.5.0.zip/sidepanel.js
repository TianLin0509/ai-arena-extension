// AI Arena — Side Panel v2.5.0

const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

const logEl = $("#log"), listEl = $("#participant-list"), countEl = $("#participant-count");
const judgeSelect = $("#judge-select");
const broadcastInput = $("#broadcast-input"), btnSend = $("#btn-send");
const btnDebate = $("#btn-debate"), btnSummary = $("#btn-summary"), btnDebateRetry = $("#btn-debate-retry");
const guidanceInput = $("#guidance-input"), roundBadge = $("#round-badge");

let participants = [], debateSession = {}, flowState = "idle", streamingPollTimer = null;

// ── PPT JSON 容错解析（移植自 ppt-assistant src/prompt/json_parser.py） ──
function parseAiJson(rawText) {
  if (!rawText || !rawText.trim()) return null;
  let text = rawText.trim();

  // 1. 提取 ```json ... ``` 代码块
  const codeBlockMatch = text.match(/```(?:json)?\s*\n?([\s\S]*?)\n?\s*```/);
  if (codeBlockMatch) text = codeBlockMatch[1].trim();

  // 2. 提取最外层大括号
  const first = text.indexOf("{");
  const last = text.lastIndexOf("}");
  if (first === -1 || last === -1 || first >= last) return null;
  text = text.substring(first, last + 1);

  // 3. 修复尾逗号
  text = text.replace(/,\s*}/g, "}").replace(/,\s*]/g, "]");

  // 4. JSON.parse
  try { return JSON.parse(text); } catch (e) {}

  // 5. 尝试单引号 → 双引号兜底（AI 偶尔会把 JSON 写成 Python dict 字面量）
  try { return JSON.parse(text.replace(/'/g, '"')); } catch (e) {}

  return null;
}

// 当前是否选中了 PPT 场景
function isPptScenarioActive() {
  const sel = scenarioMenu?.querySelector(".scenario-item.selected");
  return sel?.dataset.id === "ppt";
}

// 取该参与者最近一次完整回复（来自 background state）
async function fetchFullResponse(participantId) {
  try {
    const r = await chrome.runtime.sendMessage({
      type: "readOneResponse",
      participantId,
    });
    return r?.text || "";
  } catch (e) {
    return "";
  }
}

// ── 场景预设 ──
const SCENARIO_PRESETS = [
  { id: "analysis",  icon: "📊", label: "深度分析",
    prompt: "请从多个角度深入分析这个问题：\n1. 分别列出优势与劣势\n2. 考虑短期和长期影响\n3. 给出风险评估和可行性判断" },
  { id: "debate",    icon: "🆚", label: "正反对比",
    prompt: "请分别站在正方和反方的立场进行论证：\n1. 正方：列出支持的核心论据和证据\n2. 反方：列出反对的核心论据和证据\n3. 最后给出你的综合判断" },
  { id: "code",      icon: "💻", label: "代码审查",
    prompt: "请对代码进行全面审查，重点关注：\n1. 安全性（注入、越权、数据泄露）\n2. 性能（时间复杂度、内存、并发）\n3. 可读性与可维护性\n4. 边界情况和错误处理" },
  { id: "plan",      icon: "📝", label: "方案设计",
    prompt: "请给出详细的实施方案：\n1. 目标拆解与里程碑\n2. 具体实施步骤和时间线\n3. 所需资源和依赖\n4. 风险识别与应对策略" },
  { id: "decision",  icon: "🎯", label: "决策建议",
    prompt: "请给出明确的决策建议：\n1. 列出所有可选方案\n2. 对每个方案进行利弊权衡\n3. 给出推荐方案及核心理由\n4. 说明推荐方案的执行要点" },
  { id: "factcheck", icon: "🔍", label: "事实核查",
    prompt: "请对以下信息进行事实核查：\n1. 逐条验证关键事实的准确性\n2. 标注已确认、待确认和错误的内容\n3. 引用可靠来源佐证\n4. 指出可能的误导或遗漏" },
  { id: "ppt",       icon: "📑", label: "PPT文案",
    prompt: "你正在为一份技术汇报PPT生成文案。请严格按要求生成内容：\n1. 严格遵守每个文本框的字数范围要求，必须写满不留空白\n2. 标题必须是观点型/结论型，嵌入量化数据\n3. Bullet要点必须术语化、结论化，每条表达一个完整论点\n4. 输出严格JSON格式，不要有注释或额外解释" },
];

function mergeParticipants(remote) {
  if (!remote) return;
  const localMap = {};
  for (const p of participants) localMap[p.id] = p;
  participants = remote.map(rp => {
    const local = localMap[rp.id];
    return { ...rp, _pollStatus: local?._pollStatus || null };
  });
}
let injectResults = {}; // { participantId: "ok" | "failed" }

// ── 状态标签映射 ──
const STATE_LABELS = {
  idle: "", waiting: "等待中", streaming: "生成中", ready: "已完成"
};
const STATE_ICONS = {
  idle: "", waiting: "🤔", streaming: "⏳", ready: "✅"
};

function setEditorText(text) {
  broadcastInput.innerText = text;
  const range = document.createRange();
  range.selectNodeContents(broadcastInput);
  range.collapse(false);
  const sel = window.getSelection();
  sel.removeAllRanges();
  sel.addRange(range);
  broadcastInput.focus();
}
function getDebateRound() { return debateSession?.rounds?.length || 0; }


// ── 日志 ──
function addLog(msg, type = "info") {
  const e = document.createElement("div");
  e.className = `entry ${type}`;
  e.textContent = `[${new Date().toLocaleTimeString("zh-CN", { hour12: false })}] ${msg}`;
  logEl.prepend(e);
  while (logEl.children.length > 50) logEl.lastChild.remove();
}

// ── 渲染参与者（状态卡片） ──
function renderParticipants() {
  countEl.textContent = participants.length;
  const rounds = debateSession?.rounds?.length || 0;
  if (rounds > 0) { roundBadge.style.display = ""; roundBadge.textContent = `第${rounds}轮`; }
  else { roundBadge.style.display = "none"; }

  if (!participants.length) {
    listEl.innerHTML = '<div class="empty-hint">点击上方按钮添加参与者</div>';
  } else {
    listEl.innerHTML = participants.map(p => {
      // 轮询状态是唯一 UI 状态源
      const pState = p._pollStatus || "idle";
      const sc = (pState === "streaming" || pState === "waiting") ? "streaming" : (p.tabId ? "ready" : "offline");
      const stateLabel = STATE_LABELS[pState] || "";
      const stateIcon = STATE_ICONS[pState] || "";

      // 门控1：发送失败时显示操作按钮
      let gateActions = "";
      if (injectResults[p.id] === "failed" && flowState === "broadcasting") {
        gateActions = `<div class="p-gate-actions">
          <button class="p-gate-btn" data-action="retry" data-id="${p.id}">重试</button>
          <button class="p-gate-btn" data-action="manual-send" data-id="${p.id}">已手动发送</button>
          <button class="p-gate-btn" data-action="skip" data-id="${p.id}">跳过</button>
        </div>`;
      }

      // 实时字数显示
      const charCount = p._textLength || 0;
      const charDisplay = charCount > 0 ? `<span class="p-chars">${charCount}字</span>` : '';

      // 有效回答状态（StateMachine 中已存储回复）
      const hasResponse = !!p.responsePreview;
      const readyBadge = hasResponse
        ? `<span class="p-ready-badge ready">✓</span>`
        : `<span class="p-ready-badge not-ready">✗</span>`;

      // 手动操作按钮
      const actionBtns = !gateActions ? [
        `<button class="p-action-btn p-send" data-id="${p.id}" title="重新发送提问给该AI">🔄发送</button>`,
        `<button class="p-action-btn p-extract" data-id="${p.id}" title="手动提取该AI的回复">📋提取</button>`
      ].join('') : '';

      // PPT 场景下额外按钮：复制 JSON + 校验徽章
      const pptBtns = (isPptScenarioActive() && !gateActions && hasResponse) ? [
        `<span class="p-json-badge ${p._jsonValid === true ? 'valid' : p._jsonValid === false ? 'invalid' : 'pending'}" title="${p._jsonValid === true ? 'JSON 合法' : p._jsonValid === false ? 'JSON 不合法 — 请用 🔄 自审改进 修复' : 'JSON 校验中'}">${p._jsonValid === true ? '✅' : p._jsonValid === false ? '⚠️' : '⏳'}</span>`,
        `<button class="p-action-btn p-copy-json" data-id="${p.id}" title="解析并复制此 AI 的 JSON 输出到剪贴板">📋复制JSON</button>`
      ].join('') : '';

      return `<div class="participant-item ${p.service}">
        <span class="p-status ${sc}"></span>
        <span class="p-name">${p.name}</span>
        ${readyBadge}
        ${stateLabel ? `<span class="p-state-badge ${pState.replace(/_/g, '-')}">${stateIcon} ${stateLabel}</span>` : ''}
        ${charDisplay}
        ${gateActions}
        ${pptBtns}
        ${actionBtns}
        <button class="p-btn p-remove" data-id="${p.id}">✕</button>
      </div>`;
    }).join("");

    // 事件绑定
    listEl.querySelectorAll(".p-remove").forEach(b => b.addEventListener("click", () => chrome.runtime.sendMessage({ type: "removeParticipant", id: b.dataset.id })));
    // 手动发送按钮
    listEl.querySelectorAll(".p-send").forEach(b => b.addEventListener("click", async () => {
      const id = b.dataset.id;
      const p = participants.find(p => p.id === id);
      b.textContent = "⏳"; b.disabled = true;
      addLog(`手动发送给 ${p?.name || id}...`, "info");
      const resp = await chrome.runtime.sendMessage({ type: "sendToOne", participantId: id });
      if (resp?.ok) {
        if (p) { p._pollStatus = null; p._textLength = 0; p._jsonValid = null; }
        addLog(`已发送给 ${p?.name || id}`, "success");
        renderParticipants();
        if (!streamingPollTimer) startStreamingPoll();
      } else {
        addLog(`发送失败: ${resp?.error || '未知错误'}`, "error");
      }
      b.textContent = "🔄发送"; b.disabled = false;
    }));
    // 手动提取按钮
    listEl.querySelectorAll(".p-extract").forEach(b => b.addEventListener("click", async () => {
      const id = b.dataset.id;
      const p = participants.find(p => p.id === id);
      b.textContent = "⏳"; b.disabled = true;
      addLog(`手动提取 ${p?.name || id} 的回复...`, "info");
      const resp = await chrome.runtime.sendMessage({ type: "readOneResponse", participantId: id });
      if (resp?.ok && resp.text) {
        if (p) { p._pollStatus = "ready"; p._textLength = resp.text.length; }
        trackChars(resp.text.length);
        addLog(`${p?.name || id} 回复已提取 (${resp.text.length}字)`, "success");
        renderParticipants();
        // 检查是否所有人都 ready 了
        checkAllReadyAndConfirm();
      } else {
        addLog(`提取失败: ${resp?.error || '未读取到内容'}`, "error");
        b.textContent = "📋提取"; b.disabled = false;
      }
    }));

    // PPT 场景：复制 JSON 按钮
    listEl.querySelectorAll(".p-copy-json").forEach(b => b.addEventListener("click", async (e) => {
      e.stopPropagation();
      const id = b.dataset.id;
      const p = participants.find(p => p.id === id);
      const originalText = b.textContent;
      b.textContent = "⏳"; b.disabled = true;
      try {
        const fullText = await fetchFullResponse(id);
        if (!fullText) {
          addLog(`${p?.name || id} 暂无回复内容，请先点 📋提取`, "error");
          return;
        }
        const parsed = parseAiJson(fullText);
        if (parsed === null) {
          if (p) p._jsonValid = false;
          addLog(`${p?.name || id} 输出不是合法 JSON，请用 🔄 自审改进 让该 AI 修复`, "error");
          if ("Notification" in window && Notification.permission === "granted") {
            new Notification("AI Arena", {
              body: `${p?.name || id} 的输出不是合法 JSON。建议用「🔄 自审改进」修复后重试。`,
              silent: true,
            });
          }
          renderParticipants();
          return;
        }
        const pretty = JSON.stringify(parsed, null, 2);
        await navigator.clipboard.writeText(pretty);
        if (p) p._jsonValid = true;
        addLog(`已复制 ${p?.name || id} 的 JSON（${Object.keys(parsed).length} 个字段），切到 PPT 工具粘贴`, "success");
        if ("Notification" in window && Notification.permission === "granted") {
          new Notification("AI Arena → PPT 工具", {
            body: `已复制 ${p?.name || id} 的 JSON，建议立刻切换到 PPT 工具的 Step 4 粘贴`,
            silent: true,
          });
        }
        renderParticipants();
      } catch (err) {
        addLog(`复制失败: ${err.message}`, "error");
      } finally {
        b.textContent = originalText; b.disabled = false;
      }
    }));

    // 门控1 按钮
    listEl.querySelectorAll(".p-gate-btn").forEach(btn => {
      btn.addEventListener("click", async () => {
        const { action, id } = btn.dataset;
        if (action === "retry") {
          addLog("重试注入...", "info");
          const r = await chrome.runtime.sendMessage({ type: "retryInject", id });
          if (r?.ok) {
            injectResults[id] = "ok";
          }
        } else if (action === "manual-send") {
          injectResults[id] = "ok";
          addLog("已标记为手动发送", "info");
        } else if (action === "skip") {
          delete injectResults[id];
          addLog("已跳过", "info");
        }
        // 检查是否所有门控1都已处理
        renderParticipants();
        checkGate1Complete();
      });
    });
  }

  // 更新裁判下拉
  [judgeSelect].forEach(sel => {
    if (!sel) return;
    const cur = sel.value;
    sel.innerHTML = '<option value="">选择裁判...</option>' + participants.map(p => `<option value="${p.id}">${p.name}</option>`).join("");
    if (cur && participants.find(p => p.id === cur)) sel.value = cur;
  });

  // 辩论按钮状态：至少 2 个有效回答才能辩论
  const readyCount = participants.filter(p => !!p.responsePreview).length;
  if (btnDebate) {
    btnDebate.disabled = readyCount < 2;
    if (readyCount < 2) {
      btnDebate.title = `需要至少 2 个有效回答（当前 ${readyCount} 个）`;
    } else {
      btnDebate.title = `${readyCount} 个有效回答，可以开始辩论`;
    }
  }
}

// 门控1完成检查：injectResults 中无 failed → 自动进入 AWAITING_RESPONSES
function checkGate1Complete() {
  if (flowState !== "broadcasting") return;
  const hasFailure = Object.values(injectResults).some(v => v === "failed");
  if (!hasFailure) {
    flowState = "awaiting_responses";
    startStreamingPoll();
    addLog("所有参与者已就绪，开始等待回复...", "success");
  }
}

// 检查是否所有参与者都 ready
function checkAllReadyAndConfirm() {
  const allReady = participants.length > 0 && participants.every(p => p._pollStatus === "ready");
  if (allReady) {
    stopStreamingPoll();
    addLog("所有 AI 回复已就绪，可以开始辩论", "success");
  }
}

// ── 标记驱动轮询（纯标记+字符数，无CSS选择器） ──
let pollStartTime = 0, pollErrorCount = 0, pollReadyCount = 0;
let pollDelayTimer = null;
let prevLengths = {}; // { participantId: number }
let pollNoMarkerReported = false;
const POLL_MAX_DURATION = 10 * 60 * 1000;
const POLL_MAX_ERRORS = 10;
const POLL_READY_THRESHOLD = 2;
const POLL_INITIAL_DELAY = 2000;
const POLL_INTERVAL = 250; // 0.25 秒轮询，字数实时刷新更流畅
let lastPromptLength = 0; // 用于动态计算无标记超时

// 根据 prompt 长度动态计算无标记超时（短问题60秒，长问题更久）
function getNoMarkerTimeout() {
  // 基础60秒 + 每100字符加5秒，上限300秒
  return Math.min(60000 + Math.floor(lastPromptLength / 100) * 5000, 300000);
}

function startStreamingPoll(promptLength) {
  stopStreamingPoll();
  pollStartTime = Date.now();
  pollErrorCount = 0;
  pollReadyCount = 0;
  prevLengths = {};
  pollNoMarkerReported = false;
  if (promptLength) lastPromptLength = promptLength;
  pollDelayTimer = setTimeout(() => {
    pollDelayTimer = null;
    schedulePollTick();
  }, POLL_INITIAL_DELAY);
}

function schedulePollTick() {
  streamingPollTimer = setTimeout(async () => {
      if (Date.now() - pollStartTime > POLL_MAX_DURATION) {
        addLog("轮询超时（10分钟），已自动停止", "error");
        stopStreamingPoll();
        return;
      }
      try {
        const s = await chrome.runtime.sendMessage({ type: "checkAllCompletion" });
        pollErrorCount = 0;

        let allDone = true;
        let hasOnline = false;
        for (const [id, v] of Object.entries(s)) {
          if (v.status === "offline") continue;
          hasOnline = true;
          const prevLen = prevLengths[id] || 0;
          const lengthChanged = v.textLength !== prevLen;
          prevLengths[id] = v.textLength;

          const p = participants.find(p => p.id === id);
          if (p) {
            p._textLength = v.textLength;
            if (v.hasDone) {
              if (p._pollStatus !== "ready") {
                p._pollStatus = "ready";
                // PPT 场景：自动校验 JSON 输出
                if (isPptScenarioActive()) {
                  fetchFullResponse(id).then(fullText => {
                    p._jsonValid = parseAiJson(fullText) !== null;
                    renderParticipants();
                  });
                }
                chrome.runtime.sendMessage({ type: "readOneResponse", participantId: id }).then(resp => {
                  if (resp?.ok) {
                    if (resp.text) trackChars(resp.text.length);
                    addLog(`${p.name} 回复已自动提取`, "success");
                    // 刷新 StateMachine 数据以更新 ✓/✗ 状态
                    chrome.runtime.sendMessage({ type: "getState" }).then(state => {
                      if (state) { mergeParticipants(state.participants); renderParticipants(); }
                    });
                  }
                }).catch(() => {});
              }
            } else if (lengthChanged || v.hasStart) {
              p._pollStatus = "streaming";
            } else {
              p._pollStatus = "waiting";
            }
          }
          if (p?._pollStatus !== "ready") allDone = false;
        }
        renderParticipants();

        // 动态超时：长时间无标记 → 提示异常
        const hasAnyStart = Object.values(s).some(v => v.hasStart);
        const noMarkerTimeout = getNoMarkerTimeout();
        if (!hasAnyStart && Date.now() - pollStartTime > noMarkerTimeout && !pollNoMarkerReported) {
          pollNoMarkerReported = true;
          addLog(`⚠️ ${Math.round(noMarkerTimeout/1000)}秒内未检测到标记，疑似异常，建议手动查看`, "error");
          // 不停止轮询，继续检测，用户可用手动确认按钮
        }

        if (allDone && hasOnline) {
          pollReadyCount++;
          if (pollReadyCount >= POLL_READY_THRESHOLD) {
            addLog("所有 AI 已回答完毕（标记确认），读取回复...", "success");
            stopStreamingPoll();
            await readAllResponses();
            if (Notification.permission === "granted") {
              try { new Notification("AI Arena", { body: "所有 AI 已回答完毕，可以开始辩论", icon: "icons/icon128.png" }); } catch {}
            }
          }
        } else { pollReadyCount = 0; }
      } catch (e) {
        pollErrorCount++;
        if (pollErrorCount >= POLL_MAX_ERRORS) {
          addLog(`轮询连续失败 ${POLL_MAX_ERRORS} 次，已停止`, "error");
          stopStreamingPoll();
          return;
        }
      }
      if (streamingPollTimer !== null) schedulePollTick();
    }, POLL_INTERVAL);
}

function stopStreamingPoll() {
  if (pollDelayTimer) { clearTimeout(pollDelayTimer); pollDelayTimer = null; }
  if (streamingPollTimer) { clearTimeout(streamingPollTimer); }
  streamingPollTimer = null;
}

// 读取所有参与者的回复
async function readAllResponses() {
  for (const p of participants) {
    try {
      await chrome.runtime.sendMessage({ type: "readOneResponse", participantId: p.id });
    } catch (e) {
      addLog(`读取 ${p.name} 失败: ${e.message}`, "error");
    }
  }
  // 刷新状态
  const state = await chrome.runtime.sendMessage({ type: "getState" });
  if (state) { mergeParticipants(state.participants); debateSession = state.debateSession; flowState = state.flowState; }
  renderParticipants();
}

// ── 消息监听 ──
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "status") addLog(msg.message);
  if (msg.type === "stateUpdate") {
    mergeParticipants(msg.participants);
    debateSession = msg.debateSession || {};
    flowState = msg.flowState || "idle";
    renderParticipants();
  }
  if (msg.type === "selectorWarning") {
    addLog(msg.message, "info");
  }
  if (msg.type === "contextMenuText") {
    const text = msg.text || "";
    if (text) { setEditorText(text); addLog("已从网页获取选中文本 (" + text.length + " 字)", "info"); }
  }
});

// 初始化
(async () => {
  try {
    const r = await chrome.runtime.sendMessage({ type: "getState" });
    if (r) { mergeParticipants(r.participants); debateSession = r.debateSession || {}; flowState = r.flowState || "idle"; renderParticipants(); }
  } catch {}
})();

// 定期刷新
setInterval(async () => {
  try {
    const r = await chrome.runtime.sendMessage({ type: "getState" });
    if (r) {
      mergeParticipants(r.participants); debateSession = r.debateSession || {};
      flowState = r.flowState || "idle";
      if (!streamingPollTimer) renderParticipants();
    }
  } catch {}
}, 5000);

// ── 窗口模式切换 ──
$$(".mode-opt").forEach(btn => {
  btn.addEventListener("click", async () => {
    $$(".mode-opt").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    const mode = btn.dataset.mode;
    await chrome.runtime.sendMessage({ type: "setWindowMode", mode });
    addLog(`切换到${mode === "tiled" ? "并列" : "Tab"}模式`, "info");
    // 并列模式下自动排列已有窗口
    if (mode === "tiled" && participants.length > 0) {
      const screen = {
        width: window.screen.width,
        height: window.screen.availHeight,
        left: 0,
        top: window.screen.availTop || 0,
      };
      const r = await chrome.runtime.sendMessage({ type: "arrangeWindows", screen });
      if (r?.ok) addLog("窗口已排列", "success");
    }
  });
});

// ── 添加参与者 ──
$$(".btn-add").forEach(b => b.addEventListener("click", async () => {
  if (participants.length >= 3) { addLog("最多 3 个参与者", "error"); return; }
  addLog(`添加 ${b.dataset.service}...`);
  const screen = {
    width: window.screen.availWidth,
    height: window.screen.availHeight,
    left: window.screen.availLeft || 0,
    top: window.screen.availTop || 0,
  };
  await chrome.runtime.sendMessage({ type: "addParticipant", service: b.dataset.service, screen });
}));

// ── 文件管理 ──
let pendingImages = [], pendingFiles = [];
const imagePreviews = $("#image-previews");
const fileInput = $("#file-input");

function addImage(dataUrl) { pendingImages.push(dataUrl); renderFilePreviews(); }
function addTextFile(name, content) { pendingFiles.push({ name, content }); renderFilePreviews(); }
function removeAttachment(type, index) {
  if (type === "img") pendingImages.splice(index, 1);
  else pendingFiles.splice(index, 1);
  renderFilePreviews();
}

function renderFilePreviews() {
  let html = "";
  pendingImages.forEach((dataUrl, i) => { html += `<div class="img-preview"><img src="${dataUrl}"><button class="img-remove" data-type="img" data-idx="${i}">✕</button></div>`; });
  pendingFiles.forEach((f, i) => { html += `<div class="img-preview file-preview"><span class="file-icon">📄</span><span class="file-name">${f.name.length > 12 ? f.name.slice(0, 10) + '...' : f.name}</span><button class="img-remove" data-type="file" data-idx="${i}">✕</button></div>`; });
  imagePreviews.innerHTML = html;
  imagePreviews.querySelectorAll(".img-remove").forEach(btn => { btn.addEventListener("click", () => removeAttachment(btn.dataset.type, parseInt(btn.dataset.idx))); });
}

function fileToDataUrl(file) { return new Promise(r => { const rd = new FileReader(); rd.onload = () => r(rd.result); rd.readAsDataURL(file); }); }
function fileToText(file) { return new Promise(r => { const rd = new FileReader(); rd.onload = () => r(rd.result); rd.readAsText(file); }); }
function isImageFile(file) { return file.type.startsWith("image/"); }

broadcastInput.addEventListener("paste", async (e) => {
  const items = e.clipboardData?.items;
  if (!items) return;
  for (const item of items) {
    if (item.type.startsWith("image/")) {
      e.preventDefault();
      const file = item.getAsFile();
      if (file) { addImage(await fileToDataUrl(file)); addLog("已粘贴图片", "info"); }
    }
  }
});

fileInput.addEventListener("change", async () => {
  for (const file of fileInput.files) {
    if (isImageFile(file)) { addImage(await fileToDataUrl(file)); }
    else {
      try {
        const content = await fileToText(file);
        addTextFile(file.name, content);
        addLog(`已添加文件: ${file.name} (${(content.length / 1024).toFixed(1)}KB)`, "info");
      } catch { addLog(`无法读取文件: ${file.name}`, "error"); }
    }
  }
  fileInput.value = "";
});

broadcastInput.addEventListener("input", () => {
  broadcastInput.querySelectorAll("img").forEach(img => { if (img.src.startsWith("data:")) { addImage(img.src); img.remove(); } });
});

// ── 广播 ──
async function doBroadcast() {
  if (btnSend.disabled) return;
  btnSend.disabled = true;
  let text = broadcastInput.innerText.trim();
  const hasImages = pendingImages.length > 0;
  const hasFiles = pendingFiles.length > 0;
  if (!text && !hasImages && !hasFiles) return;
  if (!participants.length) { addLog("请先添加参与者", "error"); return; }
  const scenarios = getSelectedScenarios();
  if (scenarios.length > 0) {
    text += "\n\n" + scenarios.map(s => `【要求】${s}`).join("\n");
  }
  if (hasFiles) {
    text += pendingFiles.map(f => `\n\n---\n📄 文件: ${f.name}\n\`\`\`\n${f.content}\n\`\`\``).join("");
  }
  btnSend.disabled = true; btnSend.textContent = "发送中...";
  // 重置所有参与者的轮询状态
  participants.forEach(p => { p._pollStatus = null; p._textLength = 0; p._jsonValid = null; });
  renderParticipants();
  const attachInfo = [];
  if (hasImages) attachInfo.push(`${pendingImages.length}张图`);
  if (hasFiles) attachInfo.push(`${pendingFiles.length}个文件`);
  addLog("广播: " + text.slice(0, 50) + (text.length > 50 ? "..." : "") + (attachInfo.length ? ` (+${attachInfo.join(", ")})` : ""));
  trackConversation(participants.length);

  try {
    const r = await chrome.runtime.sendMessage({ type: "broadcast", text, images: hasImages ? pendingImages : undefined });
    if (r) {
      injectResults = {};
      for (const [id, v] of Object.entries(r)) {
        injectResults[id] = (v.status === "sent" || v.status === "inputted") ? "ok" : "failed";
        addLog(`${v.name}: ${v.status}${v.error ? " - " + v.error : ""}`, v.status === "sent" || v.status === "inputted" ? "success" : "error");
      }
    }
    broadcastInput.innerHTML = "";
    pendingImages = [];
    pendingFiles = [];
    clearScenarioSelection();
    renderFilePreviews();
    // 刷新状态
    const state = await chrome.runtime.sendMessage({ type: "getState" });
    if (state) { mergeParticipants(state.participants); flowState = state.flowState; }
    renderParticipants();
    // 如果自动进入了 awaiting，开始轮询
    if (flowState === "awaiting_responses") {
      startStreamingPoll(text.length);
    }
  } catch (e) { addLog("失败: " + e.message, "error"); }
  btnSend.disabled = false; btnSend.textContent = "发送给全部";
}
btnSend.addEventListener("click", doBroadcast);
broadcastInput.addEventListener("keydown", (e) => { if (e.key === "Enter" && e.ctrlKey) { e.preventDefault(); doBroadcast(); } });

// ── 辩论模式切换 ──
let debateMode = "free";
$$(".mode-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    $$(".mode-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    debateMode = btn.dataset.mode;
  });
});

// ── 辩论 ──
btnDebate.addEventListener("click", async () => {
  if (btnDebate.disabled) return;
  if (participants.length < 2) { addLog("至少需要 2 个参与者", "error"); return; }
  const nextRound = getDebateRound() + 1;
  btnDebate.disabled = true; btnDebate.textContent = `第${nextRound}轮...`;
  // 重置所有参与者的轮询状态（新一轮开始）
  participants.forEach(p => { p._pollStatus = null; p._textLength = 0; p._jsonValid = null; });
  renderParticipants();
  const guidance = guidanceInput?.value?.trim() || "";
  addLog(`第${nextRound}轮辩论${guidance ? " (引导: " + guidance.slice(0, 30) + ")" : ""}`, "info");
  trackDebateRound();
  try {
    const concise = $("#concise-mode")?.checked || false;
    const r = await chrome.runtime.sendMessage({ type: "debateRound", style: debateMode, guidance, concise });
    if (r?.ok) {
      addLog(`第${nextRound}轮已发送`, "success");
      // Mark non-active participants as ready so poll doesn't hang waiting for them
      if (r.activeIds) {
        participants.forEach(p => {
          if (!r.activeIds.includes(p.id)) {
            p._pollStatus = "ready";
            p._textLength = 0;
          }
        });
      }
      // 刷新状态
      const state = await chrome.runtime.sendMessage({ type: "getState" });
      if (state) { mergeParticipants(state.participants); flowState = state.flowState; }
      renderParticipants();
      if (flowState === "awaiting_responses") startStreamingPoll();
      if (guidance && guidanceInput) guidanceInput.value = "";
    } else addLog(`失败: ${r?.error}`, "error");
  } catch (e) { addLog("失败: " + e.message, "error"); }
  btnDebate.disabled = false; btnDebate.textContent = `开始辩论（第${getDebateRound() + 1}轮）`;
});

// ── 辩论重试 ──
btnDebateRetry.addEventListener("click", async () => {
  stopStreamingPoll();
  btnDebate.disabled = false;
  btnDebate.textContent = `开始辩论（第${getDebateRound() + 1}轮）`;
  btnSend.disabled = false;
  btnSend.textContent = "发送给全部";
  await chrome.runtime.sendMessage({ type: "resetSession" });
  addLog("已重置辩论状态，可以重试", "info");
});

// ── 辩论总结 ──
btnSummary.addEventListener("click", async () => {
  const judgeId = judgeSelect.value;
  if (!judgeId) { addLog("请先选择裁判", "error"); return; }
  btnSummary.disabled = true; btnSummary.textContent = "总结中...";
  addLog("生成总结...", "info");
  try {
    const r = await chrome.runtime.sendMessage({ type: "summary", judgeId });
    if (r?.ok) { addLog("总结已发送", "success"); startStreamingPoll(); }
    else addLog(`失败: ${r?.error}`, "error");
  } catch (e) { addLog("失败: " + e.message, "error"); }
  btnSummary.disabled = false; btnSummary.textContent = "输出总结";
});

// ── 导出 ──
$("#btn-export").addEventListener("click", async () => {
  try {
    const r = await chrome.runtime.sendMessage({ type: "exportSession" });
    if (!r?.ok || !r.markdown) { addLog("无辩论记录可导出", "error"); return; }
    await navigator.clipboard.writeText(r.markdown);
    addLog("辩论记录已复制到剪贴板", "success");
    const blob = new Blob([r.markdown], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ai-arena-${new Date().toISOString().slice(0, 10)}.md`;
    a.click();
    URL.revokeObjectURL(url);
    addLog("Markdown 文件已下载", "success");
  } catch (e) { addLog("导出失败: " + e.message, "error"); }
});

// ── 重置 ──
$("#btn-hard-reset").addEventListener("click", async () => {
  for (const p of participants) {
    if (p.tabId) { try { await chrome.tabs.remove(p.tabId); } catch {} }
  }
  await chrome.runtime.sendMessage({ type: "hardReset" });
  stopStreamingPoll();
  participants = [];
  debateSession = {};
  flowState = "idle";
  injectResults = {};
  pendingImages = [];
  pendingFiles = [];
  renderFilePreviews();
  broadcastInput.innerHTML = "";
  btnDebate.textContent = "开始辩论";
  btnSend.disabled = false;
  btnSend.textContent = "发送给全部";
  btnSummary.disabled = false;
  btnSummary.textContent = "输出总结";
  renderParticipants();
  addLog("已彻底重置，所有状态已清除", "success");
});


// ── 统计（本次 + 历史累计） ──
const STATS_KEY = "arena_lifetime_stats";
let lifetimeStats = { conversations: 0, debates: 0, totalChars: 0 };
let sessionStats = { conversations: 0, debates: 0, totalChars: 0 };

// 字数→Token 估算（中文~1.5 token/字，英文~1.3 token/word，取 1.4 均值）
function charsToTokens(chars) { return Math.round(chars * 1.4); }
function fmtTokens(tokens) { return tokens >= 10000 ? (tokens / 10000).toFixed(1) + '万' : tokens.toLocaleString(); }

async function loadStats() {
  const data = await chrome.storage.local.get(STATS_KEY);
  if (data[STATS_KEY]) lifetimeStats = data[STATS_KEY];
  renderStats();
}

function saveStats() {
  chrome.storage.local.set({ [STATS_KEY]: lifetimeStats });
  renderStats();
}

function renderStats() {
  // 本次
  $("#stat-s-conversations").textContent = sessionStats.conversations;
  $("#stat-s-debates").textContent = sessionStats.debates;
  $("#stat-s-tokens").textContent = fmtTokens(charsToTokens(sessionStats.totalChars));
  // 历史累计
  $("#stat-l-conversations").textContent = lifetimeStats.conversations;
  $("#stat-l-debates").textContent = lifetimeStats.debates;
  $("#stat-l-tokens").textContent = fmtTokens(charsToTokens(lifetimeStats.totalChars));
}

// 广播：对话次数 = 参与者数量（每个AI算一次对话）
function trackConversation(participantCount) {
  sessionStats.conversations += participantCount;
  lifetimeStats.conversations += participantCount;
  saveStats();
}
// 辩论：+1 轮（与参与者数无关）
function trackDebateRound() {
  sessionStats.debates++;
  lifetimeStats.debates++;
  saveStats();
}
// 回复字数累加
function trackChars(charCount) {
  sessionStats.totalChars += charCount;
  lifetimeStats.totalChars += charCount;
  saveStats();
}

// Tab 切换
$$(".stats-tab").forEach(btn => {
  btn.addEventListener("click", () => {
    $$(".stats-tab").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    const isSession = btn.dataset.tab === "session";
    $("#stats-session").style.display = isSession ? "" : "none";
    $("#stats-lifetime").style.display = isSession ? "none" : "";
  });
});

loadStats();

// ── 通知权限 ──
if ("Notification" in window) Notification.requestPermission();

// ── 场景预设下拉 ──
const scenarioMenu = $("#scenario-menu");
const btnScenario = $("#btn-scenario");

(function initScenarioMenu() {
  scenarioMenu.innerHTML = SCENARIO_PRESETS.map(s =>
    `<div class="scenario-item" data-id="${s.id}">${s.icon} ${s.label}<span class="scenario-tip">${s.prompt}</span></div>`
  ).join("");

  btnScenario.addEventListener("click", (e) => {
    e.stopPropagation();
    scenarioMenu.classList.toggle("open");
  });

  scenarioMenu.addEventListener("click", (e) => {
    e.stopPropagation();
    const item = e.target.closest(".scenario-item");
    if (!item) return;
    const id = item.dataset.id;
    const wasSelected = item.classList.contains("selected");
    scenarioMenu.querySelectorAll(".scenario-item").forEach(el => el.classList.remove("selected"));
    if (!wasSelected) item.classList.add("selected");
    updateScenarioButton();
    scenarioMenu.classList.remove("open");
  });

  document.addEventListener("click", () => {
    scenarioMenu.classList.remove("open");
  });
})();

function updateScenarioButton() {
  const sel = scenarioMenu.querySelector(".scenario-item.selected");
  if (sel) {
    const preset = SCENARIO_PRESETS.find(s => s.id === sel.dataset.id);
    btnScenario.textContent = preset ? `${preset.icon} ${preset.label} ▾` : "🎯 场景 ▾";
    btnScenario.classList.add("has-selected");
  } else {
    btnScenario.textContent = "🎯 场景 ▾";
    btnScenario.classList.remove("has-selected");
  }
}

function getSelectedScenarios() {
  const sel = scenarioMenu.querySelector(".scenario-item.selected");
  if (!sel) return [];
  const preset = SCENARIO_PRESETS.find(s => s.id === sel.dataset.id);
  return preset ? [preset.prompt] : [];
}

function clearScenarioSelection() {
  scenarioMenu.querySelectorAll(".scenario-item.selected").forEach(el => el.classList.remove("selected"));
  updateScenarioButton();
}

// ── 动态预览浮窗 ──
const dynamicTip = $("#dynamic-tip");

function truncateMiddle(text, maxLen = 300) {
  if (text.length <= maxLen) return text;
  const half = Math.floor((maxLen - 3) / 2);
  return text.slice(0, half) + "\n…\n" + text.slice(-half);
}

function buildBroadcastPreview() {
  let text = broadcastInput.innerText.trim();
  if (!text && !pendingImages.length && !pendingFiles.length) return "（空内容）";
  const scenarios = getSelectedScenarios();
  if (scenarios.length > 0) text += "\n\n" + scenarios.map(s => `【要求】${s}`).join("\n");
  if (pendingFiles.length > 0) text += pendingFiles.map(f => `\n\n📄 文件: ${f.name}`).join("");
  if (pendingImages.length > 0) text += `\n\n🖼️ ${pendingImages.length}张图片`;
  text += "\n\n（请在回答的最开头输出 ARENA_START_R{n}，最末尾输出 ARENA_DONE_R{n} 作为标记，不要解释这些标记）";
  return truncateMiddle(text, 500);
}

function buildDebatePreview() {
  const round = getDebateRound() + 1;
  const style = debateMode === "free" ? "⚔️ 自由辩论" : "🤝 群策群力";
  const guidance = guidanceInput?.value?.trim();
  const concise = $("#concise-mode")?.checked;
  const readyNames = participants.filter(p => !!p.responsePreview).map(p => p.name);
  let text = `第${round}轮 ${style}\n参与者: ${readyNames.join(", ") || "（无就绪回答）"}`;
  if (guidance) text += `\n引导: ${guidance}`;
  if (concise) text += "\n📏 简洁模式（≤1000字）";
  text += "\n\n各AI将收到其他参与者的回答，并按辩论风格回应";
  return text;
}

let dynamicTipTimer = null;

function showDynamicTip(target, content) {
  clearTimeout(dynamicTipTimer);
  dynamicTip.textContent = content;
  const rect = target.getBoundingClientRect();
  dynamicTip.style.left = Math.max(4, rect.left) + "px";
  dynamicTip.style.top = (rect.top - dynamicTip.offsetHeight - 8) + "px";
  dynamicTip.classList.add("visible");
  requestAnimationFrame(() => {
    dynamicTip.style.top = (rect.top - dynamicTip.offsetHeight - 8) + "px";
  });
}

function hideDynamicTipDelayed() {
  dynamicTipTimer = setTimeout(() => dynamicTip.classList.remove("visible"), 300);
}

function hideDynamicTipNow() {
  clearTimeout(dynamicTipTimer);
  dynamicTip.classList.remove("visible");
}

dynamicTip.addEventListener("mouseenter", () => clearTimeout(dynamicTipTimer));
dynamicTip.addEventListener("mouseleave", hideDynamicTipNow);

btnSend.addEventListener("mouseenter", () => showDynamicTip(btnSend, buildBroadcastPreview()));
btnSend.addEventListener("mouseleave", hideDynamicTipDelayed);
btnDebate.addEventListener("mouseenter", () => showDynamicTip(btnDebate, buildDebatePreview()));
btnDebate.addEventListener("mouseleave", hideDynamicTipDelayed);

// ── 快捷键 ──
document.addEventListener("keydown", (e) => {
  if (e.ctrlKey && e.shiftKey && e.key === "D") { e.preventDefault(); btnDebate.click(); }
});
